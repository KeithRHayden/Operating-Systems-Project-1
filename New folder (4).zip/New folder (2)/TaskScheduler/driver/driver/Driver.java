package driver;

import controller.Controller;

public class Driver {

	public static void main(String[] args) {
		
		Controller c = new Controller();		
		c.run();
		
	}
	

}
